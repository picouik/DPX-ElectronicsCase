# DPX Electronics Case

Server-side SPT 4.0.13 mod that adds the DPX Electronics Case, a 3x3 storage case with a 10x10 internal grid for electronics and advanced technology parts.

## Features

- Sold by Skier LL1 for 250000 roubles.
- Uses a custom graphite/PCB Items Case bundle.
- Accepts only whitelisted electronics components.
- No BepInEx plugin required.
- Does not modify SPT_Data or vanilla files.

## Installation

Place the `DPX-ElectronicsCase` folder in:

```text
SPT/user/mods/
```

Start the SPT server and check Skier LL1.

## Compatibility

Built for SPT 4.0.13 build 40087.
